const cluster = require('cluster');

const config = require('./negocio/config/config.js');
const createRandomQuery = require('./negocio/generadorQuerys/randomQuery.js');
const createRandomAnimal = require('./negocio/generadorAnimales/randomAnimal.js');
const sendToAnalytics = require("./negocio/sendToAnalytics.js");
const sendToAPI = require("./negocio/sendToAPI.js");
const sleep = require("./negocio/utils/sleep.js");


// cluster.schedulingPolicy = cluster.SCHED_RR;
cluster.schedulingPolicy = cluster.SCHED_NONE;
console.log("Inicio - processID [%d] - Worker %d", process.pid);


if (cluster.isMaster) {
    const cpuCount = require('os').cpus().length;
    const totalmem = require('os').totalmem();
    console.log("Número CPUs = [%d]", cpuCount);
    console.log("totalMem = [%d]", totalmem);
    console.log("Creando " + cpuCount + " procesos");
    for (let i = 0; i < 2; i += 1) {
        cluster.fork();
        console.log('Postfork -> fori [%d] - ' + 'processID [%d]', i, process.pid);
    }
} else {
    console.log("En else - processID [%d] - Worker %d", process.pid, cluster.worker.id);
    if (cluster.worker.id === 1) {
        console.log("worker 1");
        const limit = process.env.numElementsQuery || 10;
        // const limit =1;
        const array = [];
        for (let i = 0; i < limit; i++) {
            array.push(i)
        }
        array.forEach(() => {
            sleep(250);
            sendToAPI(createRandomQuery(), "query", cluster.worker.id);
        });


    } else {
        console.log("worker 2");
        const limit = process.env.numElementsAnimal || 10;
        // const limit = 1;
        // for (let i = 0; i < limit; i++) {

        // sendToAPI(createRandomAnimal(),"animal", cluster.worker.id, (err)=>{
        //     if(err){
        //         console.error("reenviando peticion");
        //         sendToAPI(createRandomAnimal(),"animal", cluster.worker.id);
        //     }
        // });
        const array = [];
        for (let i = 0; i < limit; i++) {
            array.push(i)
        }

        array.forEach(() => {
            sleep(1000);
            sendToAPI(createRandomAnimal(), "animal", cluster.worker.id);
        });

        // }
    }
}


cluster.on('fork', function (worker) {
    console.log('forked -> processID [%d] - Worker %d', process.pid, worker.id);
    process.env[process.pid + worker.id] = worker.id;

});