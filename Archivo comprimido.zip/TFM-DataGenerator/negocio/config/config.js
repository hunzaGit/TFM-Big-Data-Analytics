'use strict';

var config = module.exports = {
  kinesis : {
    region : 'us-east-1',
    // stream : 'kclnodejssample',
    streamTest : 'jsonTestRodriStream',
    streamQuerys : 'jsonTestRodriStream',
    streamAnimals : 'streamAnimales',
    shards : 1,
    waitBetweenDescribeCallsInSeconds : 5
  },
  mapsURL:{
    animal:"http://localhost:5555/animal",
    query: "http://localhost:5555/busqueda/avanzada",
    img_principal: "http://localhost:5555/animal/:id/imagen"
  }




};
