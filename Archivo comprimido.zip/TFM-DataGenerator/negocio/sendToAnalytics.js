'use strict';
const config = require('./config/config');

const AWS = require('aws-sdk/index');
const kinesis = new AWS.Kinesis({region: config.kinesis.region});


let log = require('./utils/logger')().getLogger('sendToAnalytics');


/** Send to analytics system the jsonObject
 *
 * @param jsonObject {{}}
 * @param type {String} type of data
 * @param workerId {Number} Id of worker
 * @param callback {Function}
 */
module.exports = (jsonObject, type, workerId = 1, callback) => {

    // console.log("En el sender!");
    // console.log("{" + workerId + "} AWS_ACCESS_KEY_ID: " + process.env.AWS_ACCESS_KEY_ID);
    // console.log("{" + workerId + "} AWS_SECRET_ACCESS_KEY: " + process.env.AWS_SECRET_ACCESS_KEY);

    // const id = 'id-' + Math.floor(Math.random() * 10000000);
    // createRandomQuery()
    const json = JSON.stringify(jsonObject);

    console.log("{" + workerId + "} Send from [" + process.env.nameSystem + "] " +
        "to [" + type + "] -> " + json.toString());

    kinesis.putRecord({
            PartitionKey: 'id-' + Math.floor(Math.random() * 10000000),
            Data: json,
            StreamName: type
        },
        (err, data) => {
            if (err) {
                log.info('------------------------------------------------');
                console.log("{" + workerId + "}" + err);

                log.error(err);
                log.info('------------------------------------------------');

            } else {
                log.info("{" + workerId + "} Successfully sent data to Kinesis.");
                console.log("{" + workerId + "} Successfully sent data to ["+type+"] Kinesis.");

                if (callback) callback();
            }
        });
};