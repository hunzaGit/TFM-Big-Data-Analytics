var util = require('util');
var logger = require('../../utils/logger');
var globalCount;
const createRandomQuery = require('../randomQuery.js');
const sendToAnalytics = require("../../sendToAnalytics.js");

function sampleProducer(kinesis, config) {
    let log = logger().getLogger('sampleProducer');

    function _createStreamIfNotCreated(callback) {
        var params = {
            ShardCount: config.shards,
            StreamName: config.stream
        };

        kinesis.createStream(params, function (err, data) {
            if (err) {
                if (err.code !== 'ResourceInUseException') {
                    callback(err);
                    return;
                } else {
                    log.info(util.format('%s stream is already created. Re-using it.', config.stream));
                }
            } else {
                log.info(util.format("%s stream doesn't exist. Created a new stream with that name ..", config.stream));
            }

            // Poll to make sure stream is in ACTIVE state before start pushing data.
            _waitForStreamToBecomeActive(callback);
        });
    }

    function _waitForStreamToBecomeActive(callback) {
        kinesis.describeStream({StreamName: config.stream}, function (err, data) {
            if (!err) {
                log.info(util.format('Current status of the stream is %s.', data.StreamDescription.StreamStatus));
                if (data.StreamDescription.StreamStatus === 'ACTIVE') {
                    callback(null);
                } else {
                    setTimeout(function () {
                        _waitForStreamToBecomeActive(callback);
                    }, 1000 * config.waitBetweenDescribeCallsInSeconds);
                }
            }
        });
    }

    function _writeToKinesis() {

    }

    return {
        run: function (workerId) {
            // _createStreamIfNotCreated(function(err) {
            //   if (err) {
            //     log.error(util.format('Error creating stream: %s', err));
            //     return;
            //   }

            console.log("{"+workerId+"} AWS_ACCESS_KEY_ID: "+process.env.AWS_ACCESS_KEY_ID);
            console.log("{"+workerId+"} AWS_SECRET_ACCESS_KEY: "+process.env.AWS_SECRET_ACCESS_KEY);


            console.log("{"+workerId+"} Mandando mensaje!");

            const limit = process.env.numElements || 10;
            for (let i = 0; i <limit; i++) {
                sendToAnalytics(createRandomQuery(), config.stream, workerId);
            }

                // count++;
            // }
            // });
        }
    };
}





module.exports = sampleProducer;
