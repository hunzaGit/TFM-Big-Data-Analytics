'use strict';

const AWS = require('aws-sdk/index');
const config = require('../../config/config');
const producerQuerys = require('./producer');

const kinesis = new AWS.Kinesis({region: config.kinesis.region});

module.exports = producerQuerys(kinesis, config.sampleProducer);