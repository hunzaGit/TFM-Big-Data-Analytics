'use strict';

var AWS = require('aws-sdk/index');
var config = require('./config');
var producerAnimals = require('./producer');

var kinesis = new AWS.Kinesis({region : config.kinesis.region});

module.exports = producerAnimals(kinesis, config.sampleProducer);