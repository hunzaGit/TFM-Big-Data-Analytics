

'use strict';

function sleep(milliseconds) {
    var start = Date.now();
    while (true) {
        let end = Date.now() - start;
        if (end > milliseconds) {
            // console.log("fin espera");
            break;
        }
    }
}

module.exports = sleep;
