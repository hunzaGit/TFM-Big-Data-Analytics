'use strict';
const config = require('./config/config');

const AWS = require('aws-sdk/index');
const kinesis = new AWS.Kinesis({region: config.kinesis.region});

const axios = require('axios');
const faker = require('faker/locale/es');
const FormData = require('form-data');
const atob = require('atob');
const Blob = require("Blob");


let log = require('./utils/logger')().getLogger('sendToAnalytics');


/** Send to analytics system the jsonObject
 *
 * @param jsonObject {{}}
 * @param type {String} type of data
 * @param workerId {Number} Id of worker
 * @param callback {Function}
 */
module.exports = (jsonObject, type, workerId = 1, callback) => {

    // console.log("En el sender!");
    // console.log("{" + workerId + "} AWS_ACCESS_KEY_ID: " + process.env.AWS_ACCESS_KEY_ID);
    // console.log("{" + workerId + "} AWS_SECRET_ACCESS_KEY: " + process.env.AWS_SECRET_ACCESS_KEY);

    // const id = 'id-' + Math.floor(Math.random() * 10000000);
    // createRandomQuery()
    const json = JSON.stringify(jsonObject);
    let url = config.mapsURL[type];


    console.log("{" + workerId + "} Send from [" + type + "] " +
        "to [" + url + "] -> " + json.toString());


    if (type === "query") {
        // http://localhost:5555/busqueda/avanzada?especie=Perro&raza=Dálmata

        url = url + "?";

        Object.keys(jsonObject).forEach((field) => {
            if (jsonObject[field] !== undefined) {
                url = url + field + "=" + jsonObject[field] + "&"
            }
        });

        // console.log("url = '" + url + "'");
        return axios.get(url)
            .then(response => {
                console.log("{" + workerId + "} Successfully sent data to [" + type + "] API --> " + response.headers["x-response-time"]);
                if (callback) callback(); else return response.status;
            })
            .catch(error => {
                console.error("**************************************");
                console.error(error);
                console.error("**************************************");
                if (callback) callback(); else return error;

            });

    } else if (type === "animal") {


        return axios.post(url,
            jsonObject,
            {
                headers: {
                    'authorization': 'Basic cm9kcmlnby50cmF6YXNAZ21haWwuY29tOjEyMzQ='
                }
            })
            .then(responseCreateAnimal => {
                console.log("{" + workerId + "} Successfully created [" + type + "] [" + responseCreateAnimal.data._id + "] in API --> " + responseCreateAnimal.headers["x-response-time"]);
                if (callback) callback(); else return responseCreateAnimal.data._id;

            })
            .catch(error => {
                console.error("**************************************");
                console.log("error.response.status  = '" + error.response.status + "'");
                console.log(error.response);
                // console.log("error.response.data.error  = '" + error.response.data.error + "'");
                error.response.data.error.forEach((err) => {
                    console.log("err = '" + err.msg + "'");
                });
                // console.error(error);

                console.error("**************************************");
                if (callback) callback(); else return error;


            });



    }
};

/**
 * Convert a base64 string in a Blob according to the data and contentType.
 *
 * @param b64Data {String} Pure base64 string without contentType
 * @param contentType {String} the content type of the file i.e (image/jpeg - image/png - text/plain)
 * @param sliceSize {Int} SliceSize to process the byteCharacters
 * @see http://stackoverflow.com/questions/16245767/creating-a-blob-from-a-base64-string-in-javascript
 * @return Blob
 */
function b64toBlob(b64Data, contentType, sliceSize) {
    contentType = contentType || '';
    sliceSize = sliceSize || 512;

    var byteCharacters = atob(b64Data);
    var byteArrays = [];

    for (var offset = 0; offset < byteCharacters.length; offset += sliceSize) {
        var slice = byteCharacters.slice(offset, offset + sliceSize);

        var byteNumbers = new Array(slice.length);
        for (var i = 0; i < slice.length; i++) {
            byteNumbers[i] = slice.charCodeAt(i);
        }

        var byteArray = new Uint8Array(byteNumbers);

        byteArrays.push(byteArray);
    }

    var blob = new Blob(byteArrays, {type: contentType});
    return blob;
}

