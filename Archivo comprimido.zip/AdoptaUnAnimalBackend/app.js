/**
 * Created by Rodrigo de Miguel on 06/2019.
 */

if (process.env.NODE_ENV === 'production') require('newrelic');
const express = require("express"),
    app = express(),
    methodOverride = require("method-override"),
    mongoose = require('mongoose'),
    morgan = require("morgan"), //Morgan nos muestra las peticiones por consola.
    expressValidator = require('express-validator'), // validador de parametros de express
    responseTime = require('response-time'),
    helmet = require('helmet'), //seguridad
    compression = require('compression'), //comprimir cabeceras HTTP
    config = require('./config.js')(),
    cors = require('cors'),
    cluster = require('cluster');




if (cluster.isMaster) {
    const cpuCount = require('os').cpus().length;
    const totalmem = require('os').totalmem();
    console.log("Número CPUs = [%d]", cpuCount);
    console.log("totalMem = [%d]", totalmem);
    console.log("Creando " + cpuCount + " procesos");
    for (let i = 0; i < cpuCount; i += 1) {
        cluster.fork();
        console.log('Postfork -> fori [%d] - ' + 'processID [%d]', i, process.pid);
    }
} else {

    const wID = cluster.worker.id;
    
//********************************************************************
//           CONFIG CORS - CROSS DOMAIN
//********************************************************************
    var corsOptions = {
        origin: [
            "www.urls_para_cors.es"
        ],
        optionsSuccessStatus: 200, // some legacy browsers (IE11, various SmartTVs) choke on 204
        methods: ['GET', 'PUT', 'POST', 'DELETE', 'OPTIONS'],
        allowedHeaders: ['Content-Type', 'Authorization'],
    };

    app.use('*', cors(corsOptions));


//********************************************************************
//           CONFIG VALIDADOR DE PARAMETROS
//********************************************************************
    app.use(expressValidator());
    app.use(expressValidator(require('./negocio/Utils/Validadores.js')));


//********************************************************************
//           CONFIG MORGAN
//********************************************************************
    app.use(methodOverride());
    app.use(morgan("dev"));


//********************************************************************
//           CONFIG ELIMINAR CABECERA
//********************************************************************
    app.disable('x-powered-by');


//********************************************************************
//           CONFIG USO DE HELMET PARA SEGURIDAD
//********************************************************************
    app.use(helmet());


//********************************************************************
//           CONFIG COMPRESION CABECERAS HTTP GZIP
//********************************************************************
    app.use(compression());


//********************************************************************
//           CONFIG TIEMPO RESPUESTA EN CABECERA HTTP
//********************************************************************
    app.use(responseTime({digits: 6}));


//********************************************************************
//            CONEXION A BBDD MONGODB
//********************************************************************

    if (process.env.NODE_ENV === 'development') {
        mongoose.set('debug', true);
    }

//Cargar los modelos
    require('./negocio/modelos/AnimalModel.js')(mongoose);
    require('./negocio/modelos/ProtectoraModel.js')(mongoose);
    require('./negocio/modelos/EmailsModel.js')(mongoose);
    let ProtectoraModel = mongoose.model('Protectora');


    mongoose.connect(config.MONGODB_URI, config.MONGO_OPTIONS);
    const db = mongoose.connection;

//********************************************************************
//            CONFIG DE ROUTERS
//********************************************************************

    app.use(require('./negocio/routers/RouterBusquedas.js'));
    app.use(require('./negocio/routers/Router_Utils.js'));


//********************************************************************
//           INICIO DE APP
//********************************************************************

    db.on('error', console.error.bind(console, 'ERROR de conexión a Mongo: '));
    db.once('open', () => {
        console.log();
        console.log("{"+wID+"} CONECTADO A MONGOO!! -->  BD: " + process.env.NODE_ENV + ' - ' + config.MONGODB_URI);


        app.listen(config.port, () => {
            console.log("{"+wID+"} Servidor arrancado en puerto " + config.port);
            console.log(config.MONGODB_URI);
            console.log("{"+wID+"} ");

            console.log("{"+wID+"} *********************************************");
            console.log("{"+wID+"} **************  PROCESS.ENV  ****************");
            console.log("{"+wID+"} *********************************************");
            console.log();
            // console.log("{"+wID+"}  --- ");
            console.log('NODE_ENV: ' + process.env.NODE_ENV);
            console.log("{"+wID+"} PORT = '" + process.env.PORT + "'");
            // console.log("{"+wID+"}  --- ");
            console.log("{"+wID+"}  --- ");
            console.log("{"+wID+"} SENDGRID_USERNAME = '" + process.env.SENDGRID_USERNAME + "'");
            console.log("{"+wID+"}  --- ");
            console.log("{"+wID+"} MONGODB_URI = '" + process.env.MONGODB_URI + "'");
            console.log("{"+wID+"}  --- ");
            console.log("{"+wID+"} EMAIL_CORPORATIVO_ADOPTA_UN_ANIMAL = '" + process.env.EMAIL_CORPORATIVO_ADOPTA_UN_ANIMAL + "'");
            console.log("{"+wID+"}  --- ");
            console.log("{"+wID+"} MONGODB_URI_LOCALHOST = '" + process.env.MONGODB_URI_LOCALHOST + "'");
            console.log("{"+wID+"} MONGODB_URI_DEVELOPMENT = '" + process.env.MONGODB_URI_DEVELOPMENT + "'");

            console.log("{"+wID+"} *********************************************");
            console.log("{"+wID+"} *********************************************");


        });


    });

}