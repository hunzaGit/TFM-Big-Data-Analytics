/**
 * Created by Rodrigo de Miguel on 06/2019.
 */

const mongoose = require('mongoose');

const AnimalModel = mongoose.model('Animal'),
    ProtectoraModel = mongoose.model('Protectora'),
    EmailModel = mongoose.model('Email'),
    config = require('../../config.js')('dev'),

    parametros = require('../../config.js').parametros,
    tEmail = parametros.tipos_de_email,
    errores = require('../Utils/Errores.js'),
    enviarEmail = require('../Utils/ControladorEmail.js'),
    te = parametros.tipos_de_email;


//*************************************************************************
//******************** Funciones de envio de email ************************
//*************************************************************************


exports.enviarEmail = (req, res) => {
    console.log("enviando email de prueba");

    //tipoEmail, fromEmail, toEmail, texto, datos, callback = Function()) {


    validarDatos(req, (arrayErrores, datos) => {
        if (arrayErrores) return res.status(500).json(errores.std.ERROR_ENVIAR_EMAIL.msg);

        console.log('Datos validados');


        obtenerDatosParaEmail(datos, (errObtenerDatos, datosEmail) => {
            if (errObtenerDatos) {
                return res.status(500).json(errores.std.ERROR_ENVIAR_EMAIL.msg);
            } else {
                console.log("protectora buscada:");
                console.log(datosEmail.protectora.nombre);

                enviarEmail(datosEmail, (errorEnvio, sendOK, datosEmailEnviado) => {
                        if (errorEnvio) {
                            console.error("ocurrio un error enviando email");
                            res.status(500).json(errores.std.ERROR_ENVIAR_EMAIL.msg);
                        } else {

                            const email = new EmailModel({
                                from: datosEmailEnviado.fromEmail,
                                to: datosEmailEnviado.toEmail,
                                asunto: datosEmailEnviado.asunto,
                                tipo: datosEmailEnviado.tipoEmail,
                                protectora: (datosEmailEnviado.protectora) ? datosEmailEnviado.protectora._id : undefined,
                                animal: (datosEmailEnviado.animal) ? datosEmailEnviado.animal._id : undefined,
                                textoUsuario: datosEmailEnviado.texto,
                                html: datosEmailEnviado.html
                            });

                            console.log("*****************************************************");
                            console.log("********  datos email guardado en BBDD **************");
                            console.log(email);
                            console.log("*****************************************************");
                            console.log("*****************************************************");

                            email.save()
                                .then(function (email) {
                                    console.log("email guardado en BBDD");
                                    res.status(200).json({status: "ok"});


                                }, function (errSave) {
                                    console.error("Error al guardar email en el sistema");
                                    console.error(errSave);
                                    if (errSave) {
                                        return res.status(500).json(errores.std.ERROR_AL_REGISTRAR_EMAIL_EN_BBDD.msg);
                                    }
                                });

                        }

                    }
                );
            }
        });


    });


};


exports.enviarEmailTest = (req, res) => {
    console.log("enviando email de prueba");

    //tipoEmail, fromEmail, toEmail, datos, callback = Function()) {

    ProtectoraModel.findById("5991d4d11164021f2064984e", {}, (err, protectora) => {
        if (err) return res.status(500).json(err.message);

        enviarEmail({
                tipoEmail: tEmail.paraAdmin_registro_de_Protectora,
                fromEmail: config.EMAIL_CORPORATIVO_ADOPTA_UN_ANIMAL,
                toEmail: "rodrigo.trazas@gmail.com",
                protectora: protectora
            }, (error) => {
                if (error) {
                    console.error("ocurrio un error enviando email");
                    res.status(500).json({
                        status: "error enviando email",
                        error: error
                    });
                } else {


                    res.status(200).json({status: "ok"});
                }

            }
        );

    });


};


//*************************************************************************
//*********************** Funciones auxiliares ****************************
//*************************************************************************


function validarDatos(req, callback = Function()) {

    // DATOS
    // toEmail, fromEmail, tipoEmail, protectora, animal, texto

    console.log("********************************");
    console.log("*********  req.body  ***********");
    console.log(req.body);
    console.log("********************************");
    console.log("********************************");


    // req.sanitizeBody("toEmail").trim();
    // req.checkBody('toEmail').isEmail().withMessage(errores.validacion.EMAIL_INCORRECTO.msg);


    req.sanitizeBody("fromEmail").trim();
    req.checkBody('fromEmail').isEmail().withMessage(errores.validacion.EMAIL_INCORRECTO.msg);


    req.sanitizeBody("tipoEmail").trim();
    req.checkBody('tipoEmail').isIn(Object.keys(parametros.tipos_de_email)).withMessage(errores.validacion.TIPO_EMAIL_INCORRECTO.msg);

    if (req.body.texto) {

        req.sanitizeBody("texto").trim().toString();

        req.checkBody('texto')
            .notEmpty().withMessage(errores.validacion.TEXTO_EMAIL_REQUERIDO.msg);

    }

    if (req.body.protectora) {
        req.sanitizeBody("protectora").trim();
        req.checkBody('protectora').isMongoId().withMessage(errores.validacion.MONGOID_REQUERIDO.msg);
    }


    if (req.body.animal) {
        req.sanitizeBody("animal").trim();
        req.checkBody('animal').isMongoId().withMessage(errores.validacion.MONGOID_REQUERIDO.msg);
    }


    req.getValidationResult().then(function (result) {
        if (!result.isEmpty()) console.log(result.array());
        if (!result.isEmpty()) callback(result.array());
        else callback(null, req.body);
    });


}

/** Obtencion de datos para el email
 *
 * @param datos {Object} -> Datos necesarios para el envio
 * @param datos.tipoEmail {String} -> Tipo de Email
 * @param datos.fromEmail {String} -> Direccion email origen
 * @param datos.toEmail {String} -> Direccion email Destino
 * @param datos.protectora? {MongoID} -> Objecto protectora con los datos
 * @param datos.animal? {MongoID} -> Objecto animal con los datos
 *
 * @param callback
 *
 * @callback callback function(err, data)
 *   @param err [Error] an error or null if no error occurred.
 *   @param datos [Map] an error or null if no error occurred.
 */
function obtenerDatosParaEmail(datos, callback = Function()) {


    let todoOK = false,
        msg = "",
        buscarAnimalConProctora = false;


    switch (datos.tipoEmail) {
        case te.nuevo_animal_suscripcion_filtro: {
            if (datos.animal) {
                buscarAnimalConProctora = true;
                todoOK = true;
            } else {
                msg = "Falta parametro animal";
            }
        }


    }


    console.log("BUSCANDO ANIMAL CON PROTECOTRA PARA EMAIL...");

    AnimalModel.findById(datos.animal, {})
        .then((animal) => {
            if (animal) {

                ProtectoraModel.populate(animal, {
                    path: 'protectora',
                    select: {nombre: 1, email: 1, telefonos: 1, URL: 1, direccion: 1}
                }, (errPopulate, animalPop) => {
                    if (errPopulate) return callback(new Error(errPopulate.message));


                    console.log(animal.nombre);
                    datos.animal = animal;
                    datos.protectora = animalPop.protectora;


                    if (todoOK) {
                        callback(null, datos);
                    }
                });


            } else {
                callback(new Error(errores.std.ERROR_ANIMAL_NO_ENCONTRADO.msg));
            }
        })
        .catch((errFind) => {
            if (errFind) {
                msg = errFind.message;
                todoOK = false;
            }

            console.error("Error en busqueda de datos para email");
            console.error(msg);
            callback(new Error(msg));
        });


}

