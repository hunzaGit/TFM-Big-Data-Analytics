/**
 * Created by Rodrigo de Miguel on 06/2019.
 */
const mongoose = require('mongoose'),
    mime = require('mime-types');

const AnimalModel = mongoose.model('Animal'),
    ProtectoraModel = mongoose.model('Protectora'),
    config = require('../../config.js')('dev'),

    parametros = require('../../config.js').parametros,
    errores = require('../Utils/Errores.js'),
    sendToAnalytics = require("../analytics/sendToAnalytics.js");


/** filtra el objeto query para el envio a analytica
 *
 * @param query {{}}
 */
function filterQueryToAnalytics(query) {

    const queryFiltered = {
        especie: query.especie,
        raza: query.raza,
        estado: query.estado,
        sexo: query.sexo,
        tamano: query.tamano,
        edad: query.edad,
        color: query.color,
        caracter: query.caracter,
        chip: query.chip,
        ppp: query.ppp,
        pag: query.pag,
    };


    if (query.user_lat && query.user_lon) {
        queryFiltered.location = {
            lat: query.user_lat,
            lon: query.user_lon
        }

        queryFiltered.maxDistance = query.maxDistance;

    }


    console.log("queryFiltered");
    console.log(queryFiltered);
    return queryFiltered;


}


exports.suscripcionFiltro = (req, res) => {

    //ESPECIE, RAZA, SEXO, TAMAÑO, EDAD e EMAIL

    console.log("-- VALIDACION PARAMETROS BASICOS");
    validacionParametrosSuscripcionFiltro(req, (errBasica, body) => {

        if (errBasica) {
            console.error('hay ERROR Basica: ');
            console.error(errBasica);
            res.status(400).json(errBasica);
        } else {


            console.log("body = '" + body + "'");
            
            sendToAnalytics(body, "suscripcion", (err, result) => {
                if (err) {
                    res.status(500).json(errores.std.ERROR_AL_SUSCRIBIR_FILTRO.msg);
                } else {
                    res.status(201).json("Suscripción realizada con existo");
                }
            });

        }
    });
};


/** filtra el objeto query+email para el envio a analytica y suscripción
 *
 * @param record {{}}
 */
function normalizarRecordSuscripcionToAnalytics(record) {


    const recordFiltered = {
        especie: record.especie,
        raza: record.raza,
        sexo: record.sexo,
        tamano: record.tamano,
        edad: record.edad,
        email: record.email
    };

    console.log("queryFiltered");
    console.log(recordFiltered);
    return recordFiltered;


}


//*************************************************************************
//*********************** Funciones auxiliares ****************************
//*************************************************************************



/** Valida los parametros en el cuerpo de la peticion para la suscrpción al filtro
 *
 * @param req.body {{}} -> Request Body
 * @param req.body.especie {String} -> Parametro especie
 * @param req.body.raza {String} -> Parametro raza
 * @param req.body.sexo {String} -> Parametro sexo
 * @param req.body.tamano {String} -> Parametro tamano
 * @param req.body.edad {String} -> Parametro edad
 * @param req.body.email {String} -> Parametro email
 *
 * @param req.sanitizeBody {Function}
 * @param req.checkBody {Function}
 * @param req.getValidationResult {Function}
 *
 * @param callBack
 */
function validacionParametrosSuscripcionFiltro(req, callBack = Function()) {

    console.log("especie = [" + req.body.especie + "]");
    console.log("raza = [" + req.body.raza + "]");
    console.log("sexo = [" + req.body.sexo + "]");
    console.log("tamano = [" + req.body.tamano + "]");
    console.log("edad = [" + req.body.edad + "]");
    console.log("email = [" + req.body.email + "]");

    if (req.body.especie) {
        req.sanitizeBody('especie').trim();
        req.checkBody('especie')
            .isIn(parametros.especie_animal)
            .withMessage(errores.validacion.ESPECIE_INCORRECTA.msg);
    }


    if (req.body.raza) {

        req.sanitizeBody('raza').trim();
        req.checkBody('raza')
            .razaAnimalCorrecto(req.body.especie)
            .withMessage(errores.validacion.RAZA_ERRONEA.msg);
    }


    if (req.body.sexo) {
        req.sanitizeBody('sexo').trim();
        req.checkBody('sexo')
            .sexoAnimalCorrecto()
            .withMessage(errores.validacion.SEXO_ERRORNEO.msg);
    }


    if (req.body.tamano) {
        req.sanitizeBody('tamano').trim();
        req.checkBody('tamano')
            .tamanoAnimalCorrecto()
            .withMessage(errores.validacion.TAMANO_ERRONEO.msg);

    }


    if (req.body.edad) {
        req.sanitizeBody('edad').trim();
        req.checkBody('edad')
            .edadAnimalCorrecto()
            .withMessage(errores.validacion.EDAD_INCORRECTA.msg);
    }


    req.sanitizeBody('email').trim();
    req.checkBody('email')
        .isEmail()
        .withMessage(errores.validacion.EMAIL_INCORRECTO);


    req.getValidationResult().then(function (result) {
        if (result.isEmpty()) {
            callBack(undefined, req.body);
        } else {
            callBack(result.array(), undefined);
        }

    });

};

