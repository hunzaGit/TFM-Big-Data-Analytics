/**
 * Created by Rodrigo de Miguel on 06/2019.
 */
'use strict';
const config = require('../../config.js')('dev');

const AWS = require('aws-sdk/index');
const kinesis = new AWS.Kinesis({region: config.kinesis.region});
// const kinesis = config.CREAR_CLIENTE_AWS_KINESIS();


// let log = require('./utils/logger')().getLogger('sendToAnalytics');


/** Send to analytics system the jsonObject
 *
 * @param jsonObject {{}}
 * @param type {String} type of data
 * @param workerId {Number} Id of worker
 * @param callback {Function}
 */
module.exports = (jsonObject, type, workerId = 1, callback) => {
    if (workerId instanceof Function){
        callback = workerId;
        workerId = 1;
    }

    console.log("En el sender!");
    //console.log("{" + workerId + "} AWS_ACCESS_KEY_ID: " + process.env.AWS_ACCESS_KEY_ID);
    //console.log("{" + workerId + "} AWS_SECRET_ACCESS_KEY: " + process.env.AWS_SECRET_ACCESS_KEY);

    if (jsonObject.timestamp === undefined) {
        jsonObject.timestamp = Date.now();
    }

    const json = JSON.stringify(jsonObject);
    const stream = config.kinesis.mapsStreams[type];

    console.log("{" + workerId + "} Send from [" + (process.env.nameSystem || "localhost") + "] " +
        "to [" + stream + "] -> " + json.toString());

    kinesis.putRecord({
            PartitionKey: 'id-' + Math.floor(Math.random() * 10000000),
            Data: json,
            StreamName: stream
        },
        (err, data) => {
            if (err) {
                // log.info('------------------------------------------------');
                console.log("{" + workerId + "} " + err);
                if (callback) callback(err);

                // log.info('------------------------------------------------');
            } else {
                console.log("{" + workerId + "} Successfully sent data to [" + stream + "] Kinesis.");
                if (callback) callback();

            }

        });
};