/**
 * Created by Rodrigo de Miguel on 06/2019.
 */


const router_emails = require("express").Router(),
    SA_Emails = require('../Serv_aplicacion/SA_Emails.js');


router_emails.route('/utils/enviarEmail')
    .post(SA_Emails.enviarEmail);

module.exports = router_emails;
