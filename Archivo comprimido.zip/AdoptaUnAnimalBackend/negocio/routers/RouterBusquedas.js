/**
 * Created by Rodrigo de Miguel on 06/2019.
 */


const router_animales = require("express").Router(),
    SA_Busquedas = require('../Serv_aplicacion/SA_Busquedas.js');


router_animales.route('/busqueda/suscripcionFiltro')
    .post(SA_Busquedas.suscripcionFiltro);


module.exports = router_animales;
