/**
 * Created by Rodrigo de Miguel on 06/2019.
 */
const parametros = require('../../config').parametros;

exports = module.exports = function (mongoose) {


    const EmailSchema = new mongoose.Schema({
        nombre: {type: String},
        from: {type: String},
        to: {type: String},
        asunto: {type: String},
        tipo: {type: String},
        protectora: {type: mongoose.Schema.ObjectId, ref: 'Protectora'},
        animal: {type: mongoose.Schema.ObjectId, ref: 'Animal'},
        textoUsuario: {type: String},
        html: {type: String},
        fecha_envio: {type: Date, default: Date.now},
    });

    mongoose.model('Email', EmailSchema);

};
