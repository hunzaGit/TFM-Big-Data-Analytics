/**
 * Created by Rodrigo de Miguel on 06/2019.
 */
const config = require('../../config.js')('dev'),
    parametros = require('../../config').parametros,
    encrypt = require('mongoose-encryption');


exports = module.exports = function (mongoose) {

    const ProtectoraSchema = new mongoose.Schema({
        nombre: {type: String, required: false, unique: true},
        password: {type: String, required: true},
        NIF: {type: String, required: false},
        URL: {type: String},
        facebook: {type: String},
        descripcion: {type: String},
        direccion: {
            calle: {type: String, required: true},
            cod_Postal: {type: String, required: false},
            municipio: {type: String, required: false},
            provincia: {type: String, required: false},
            pais: {type: String, required: false},
            coordenadas_GPS: {
                type: {type: String, default: 'Point'},
                coordinates: {type: [Number], default: [40.4167, -3.70325]}
            },
        },
        telefonos: [
            {
                telefono: String,
                WhatsApp: Boolean
            }
        ],
        email: {type: String, required: false, unique: true},
        logo: {
            url: {type: String},
            encodeURI: {type: String}
        },
        fecha_registro: {type: Date, default: Date.now},
    });

    ProtectoraSchema.plugin(encrypt, {
        encryptionKey: config.ENCRYPTATION_KEY,
        signingKey: config.SIGNING_KEY,
        encryptedFields: ['password']
    });


    mongoose.model('Protectora', ProtectoraSchema);

};