/**
 * Created by Rodrigo de Miguel on 06/2019.
 */

const parametros = require('../../config').parametros;

exports = module.exports = function (mongoose) {

    const AnimalSchema = new mongoose.Schema({
        nombre: {type: String},
        especie: {type: String, enum: parametros.especie_animal, required: true},
        raza: {type: [String], required: true},
        sexo: {type: String, enum: parametros.sexos, required: true},
        tamano: {type: String, enum: parametros.tamanos_animal, required: true},
        edad: {type: String, enum: parametros.edades_animal, required: true},
        fecha_registro: {type: Date, default: Date.now},
        estado: {type: String, enum: parametros.estados_animal, required: true},
        img_principal: {
            url: {type: String},
            encodeURI: {type: String}
        },
        direccion: {
            cod_Postal: {type: String, required: true},
            municipio: {type: String, required: true},
            provincia: {type: String, required: true},
            coordenadas_GPS: {
                type: {type: String, default: 'Point'},
                coordinates: {type: [Number]}
            },
        },
        protectora: {type: mongoose.Schema.Types.ObjectId, ref: 'Protectora'}
    });

    mongoose.model('Animal', AnimalSchema);

};
