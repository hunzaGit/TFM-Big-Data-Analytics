/**
 * Created by Rodrigo de Miguel on 06/2019.
 */
exports.std = {

    ERROR_BUSCAR_PROTECTORA: {
        code: 103,
        msg: 'Error al buscar protectora.'
    },
    ERROR_AL_REGISTRAR: {
        code: 104,
        msg: 'Ocurió un error al registrar la entidad.' // este mensaje se puede sustituir por el que retorna mongoose
    },
    ERROR_AL_VERIFICAR: {
        code: 107,
        msg: 'Error al verificar protectora.'
    },
    ERROR_BUSCAR_PROTECTORAS: {
        code: 108,
        msg: 'Error al buscar las protectoras.'
    },
    ERROR_ANIMAL_NO_ENCONTRADO: {
        code: 114,
        msg: 'No se encontro el animal buscado' // este mensaje se puede sustituir por el que retorna mongoose
    },
    ERROR_BUSCAR_ANIMAL: {
        code: 117,
        msg: 'Ocurió un error al buscar el animal'
    },

    ERROR_PROTECTORA_NO_ENCONTRADA: {
        code: 123,
        msg: 'No se encontro la protectora buscada' // este mensaje se puede sustituir por el que retorna mongoose
    },
    ERROR_ENVIAR_EMAIL: {
        code: 124,
        msg: 'Hubo un error al enviar el email'
    },
    ERROR_AL_REGISTRAR_EMAIL_EN_BBDD: {
        code: 127,
        msg: "Error al guardar email en BBDD."
    },
    ERROR_AL_SUSCRIBIR_FILTRO: {
        code: 130,
        msg: "Error al suscribir el email al filtro."
    }


};


//*****************************************************
//*************** ERRORES DE VALIDACIÓN ***************
//*****************************************************
exports.validacion = {
    NOMBRE_REQUERIDO: {
        code: 201,
        msg: 'Se requiere un nombre.'
    },

    ESPECIE_REQUERIDA: {
        code: 224,
        msg: 'Se requiere una especie de animal.'
    },
    RAZA_REQUERIDA: {
        code: 225,
        msg: 'Se requiere una raza de animal.'
    },
    RAZA_ERRONEA: {
        code: 226,
        msg: 'Raza erronea.'
    },

    SEXO_REQUERIDO: {
        code: 228,
        msg: 'Se requiere un sexo del animal.'
    },
    TAMANO_REQUERIDO: {
        code: 229,
        msg: 'Se requiere un tamaño del animal.'
    },
    TAMANO_ERRONEO: {
        code: 230,
        msg: 'Tamaño del animal erroneo'
    },
    ESTADO_ANIMAL_INCORRECTO: {
        code: 235,
        msg: 'El estado del animal es incorrecto.'
    },
    PARAMETRO_MAL_ESPECIFICADO: {
        code: 236,
        msg: 'Parametro de la plataforma mal especificado.'
    },
    ESPECIE_INCORRECTA: {
        code: 237,
        msg: 'Especie incorrecta'
    },
    EDAD_INCORRECTA: {
        code: 238,
        msg: 'Edad de animal incorrecta'
    },
    SEXO_ERRORNEO: {
        code: 247,
        msg: "Sexo del animal erroneo."
    },
    TIPO_EMAIL_INCORRECTO: {
        code: 250,
        msg: "El tipo de email es incorrecto."
    },
    TEXTO_INCORRECTO: {
        code: 251,
        msg: "El texto es incorrecto."
    },
    TEXTO_EMAIL_REQUERIDO: {
        code: 255,
        msg: "Se debe escribir un texto para el email."
    }

};