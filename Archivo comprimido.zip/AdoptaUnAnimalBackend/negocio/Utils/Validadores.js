/**
 * Created by Rodrigo de Miguel on 06/2019.
 */
const parametros = require('../../config').parametros;


module.exports = {
    customValidators: {
        isArray: (value) => {
            console.log(Array.isArray(value));
            return Array.isArray(value);
        },


        razaAnimalCorrecto: (razasValues, especie) => {
            var todoOK = true;
            console.log();
            console.log("--------  EN VALIDADOR CUSTOM RAZA  --------")
            console.log("Especie URL: " + especie);
            console.log('Raza URL: ' + razasValues);
            //Si la especie es valida...
            if (parametros.especie_animal.indexOf(especie) !== -1) {

                razasValues = razasValues.split(',');

                //si hay alguna raza erronea se retorna error
                razasValues.forEach((raza) => {
                    if (parametros['razas_' + especie].indexOf(raza) === -1) {
                        console.log("Raza errornea: " + raza);
                        todoOK = false;
                    }
                });

            } else {
                todoOK = false;
            }


            console.log("hayError raza: " + !todoOK);
            console.log("----------------------------------------------")
            console.log("");
            return todoOK; //true val correcto, false hay error
        },

        tamanoAnimalCorrecto: (tamanoValue) => {
            let hayError = false;

            console.log();
            console.log("--------  EN VALIDADOR CUSTOM TAMANO  --------")
            console.log('Tamano URL: ' + tamanoValue);
            tamanoValue = tamanoValue.split(',');

            //si hay algun tamaño erroneo se retorna error
            tamanoValue.forEach((tam) => {
                if (parametros.tamanos_animal.indexOf(tam.toUpperCase()) === -1) {
                    console.log("Tamano errornea: " + tam);
                    hayError = true;
                }
            });

            console.log("hayError tamano: " + hayError);
            console.log("----------------------------------------------")
            console.log("");
            return !hayError; //true val correcto, false hay error

        },

        edadAnimalCorrecto: (edadValue) => {

            var hayError = false;
            console.log();
            console.log("--------  EN VALIDADOR CUSTOM EDAD  --------")
            console.log('Edad URL: ' + edadValue);
            edadValue = edadValue.split(',');


            //si hay alguna edad erronea se retorna error
            edadValue.forEach((edad) => {
                if (parametros.edades_animal.indexOf(edad.toUpperCase()) === -1) {
                    console.log("Edad errornea: " + edad);
                    hayError = true;
                }
            });


            console.log("hayError edad: " + hayError);
            console.log("----------------------------------------------")
            console.log("");
            return !hayError; //true val correcto, false hay error


        },

        sexoAnimalCorrecto: (sexoValue) => {

            var hayError = false;
            console.log();
            console.log("--------  EN VALIDADOR CUSTOM SEXO  --------")
            console.log('Sexo URL: ' + sexoValue);
            sexoValue = sexoValue.split(',');
            console.log("sexoValue: " + sexoValue);

            //si hay alguna edad erronea se retorna error
            sexoValue.forEach((sexo) => {
                if (parametros.sexos.indexOf(sexo.toUpperCase()) === -1) {
                    console.log("Sexo errorneo: " + sexo);
                    hayError = true;
                }
            });


            console.log("hayError sexo: " + hayError);
            console.log("----------------------------------------------")
            console.log("");
            return !hayError; //true val correcto, false hay error
        },

    }

};