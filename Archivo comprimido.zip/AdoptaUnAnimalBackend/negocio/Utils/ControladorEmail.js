/**
 * Created by Rodrigo de Miguel on 06/2019.
 */
const config = require('../../config.js')('dev'),
    fs = require('fs'), // Sistema de ficheros
    parametros = require('../../config.js').parametros,
    hogan = require("hogan.js"),
    SendGrid = require('sendgrid')(config.EMAIL_API),
    helper = require('sendgrid').mail,
    te = parametros.tipos_de_email,
    emailValidator = require("email-validator");

const template_nuevo_animal_suscripcion_filtro = hogan.compile(fs.readFileSync("resources/emails/Nuevo_animal_suscripcion_filtro.hjs", "utf-8"));

/** Envia un email con los parámetros indicados
 *
 * @param datos {Map} -> Datos necesarios para el envio
 * @param datos.tipoEmail {String} -> Tipo de Email
 * @param datos.fromEmail {String} -> Direccion email origen
 * @param datos.toEmail {String} -> Direccion email Destino
 * @param datos.tipoEmail {String} -> Tipo de Email
 * @param datos.texto? {String} -> texto del usuario
 * @param datos.protectora? {Object} -> Objecto protectora con los datos
 * @param datos.animal? {Object} -> Objecto animal con los datos
 *
 * @param callback
 *
 * @callback callback function(err, data)
 *   @param err [Error] an error or null if no error occurred.
 */
module.exports = function (datos, callback = Function()) {
    console.log("");
    console.log("******************************");
    console.log('**** Enviando email: ' + datos.tipoEmail);
    console.log("******************************");


    validacionDeParametros(datos, (errValid) => {
        if (errValid) {
            callback(errValid, undefined);
        } else {

            procesarEmail(datos.tipoEmail, datos, (email) => {
                datos.html = email.html;
                datos.asunto = email.asunto;
                //Datos de envio
                const fromEmail = new helper.Email(datos.fromEmail),
                    toEmail = new helper.Email(datos.toEmail),
                    subject = email.asunto,
                    content = new helper.Content('text/HTML', email.html),
                    mail = new helper.Mail(fromEmail, subject, toEmail, content);


                const request = SendGrid.emptyRequest({
                    method: 'POST',
                    path: '/v3/mail/send',
                    body: mail.toJSON()
                });


                SendGrid.API(request, function (errorEnvio, response) {
                    console.log('RESULTADO DEL ENVIO DE MAIL: ' + response.statusCode);

                    if (errorEnvio) {
                        console.error('Error response received');
                        console.log(errorEnvio);
                    }

                    if (response.statusCode === 202) {
                        console.log("--- Envio email correcto ---");
                        callback(null, true, datos);
                    } else {
                        callback(errorEnvio, false);
                    }
                });
            });
        }
    });
};


/** Renderiza la plantilla HTML indicada por parametro
 *
 * @param tipoEmail {String} -> tipo de Email
 * @param datos {Object} -> {portectora, errores,}
 * @param callBack
 *
 * @callback callback function(err, data)
 *   @param email [Map] objeto email con el HTML y el asunto
 *   @param email.html [String] HTML cargado con la plantilla y los datos
 *   @param email.asunto [String] String con el asunto del email
 */
function procesarEmail(tipoEmail, datos, callBack = Function()) {

    console.log("procesando email tipo: " + tipoEmail);
    var email = {
        html: "",
        asunto: ""
    };

    switch (tipoEmail) {

        case te.nuevo_animal_suscripcion_filtro: {
            email.html = template_nuevo_animal_suscripcion_filtro.render({
                protectora: datos.protectora,
                // texto: datos.texto
                animal: datos.animal

            });

            email.asunto = parametros.asuntos_email[te.nuevo_animal_suscripcion_filtro];

        }
    }


    callBack(email);

}


/** Valida los parametros de entrada
 *
 * @param datos {Object} -> Datos necesarios para el envio
 * @param datos.tipoEmail {String} -> Tipo de Email
 * @param datos.fromEmail {String} -> Direccion email origen
 * @param datos.toEmail {String} -> Direccion email Destino
 * @param datos.protectora? {Object} -> Objecto protectora con los datos
 * @param datos.animal? {Object} -> Objecto animal con los datos
 * @param datos.error? {Object} -> Objecto protectora con los datos
 *
 * @param callback
 *
 * @callback callback function(err, data)
 *   @param err [Error] an error or null if no error occurred.
 */
function validacionDeParametros(datos, callback = Function()) {


    var todoOK = false,
        msg = "";

    if (datos) {

        if (datos.tipoEmail && parametros.tipos_de_email[datos.tipoEmail] !== undefined) {
            console.log("datos.tipoEmail CORRECTO");
            if (datos.fromEmail && emailValidator.validate(datos.fromEmail)) {
                console.log("datos.fromEmail CORRECTO");
                if (datos.toEmail && emailValidator.validate(datos.toEmail)) {
                    console.log("datos.toEmail CORRECTO");


                    switch (datos.tipoEmail) {
                        case te.nuevo_animal_suscripcion_filtro: {
                            if (datos.protectora) {
                                console.log("datos.protectora CORRECTO");
                                if (datos.animal) {
                                    console.log("datos.animal CORRECTO");

                                    todoOK = true;
                                } else {
                                    msg = "Falta parametro animal";
                                }
                            } else {
                                msg = "Falta parametro protectora";
                            }


                        }
                    }

                } else {
                    msg = "Falta o es incorrecto el parametro toEmail";
                }

            } else {
                msg = "Falta o es incorrecto el parametro fromEmail";
            }

        } else {
            msg = "Falta parametro tipoEmail";
        }

    } else {
        msg = "Objeto invalido"
    }


    if (todoOK) {

        callback(null);
    } else {
        console.error("Error en validacion de envio email");
        console.error(msg);
        callback(new Error(msg));
    }
}

