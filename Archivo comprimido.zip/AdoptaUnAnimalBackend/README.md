# AdoptaUnAnimal

## Infografía de tecnologías 
![](public/Diagrama_Tecnologia.png)
