var AWS = require('aws-sdk');

module.exports = () => {
    "use strict";

    //var oper = process.env.ESTADO_DESAROLLO || 'dev';


    //******************************************
    //          CONFIGURACIÓN BBDD
    //******************************************


    return {
        port: process.env.PORT || 5555,

        MONGODB_URI: process.env.MONGODB_URI_DEVELOPMENT || process.env.MONGODB_URI_PRODUCTION,

        MONGO_OPTIONS: {
            server: {socketOptions: {keepAlive: 300000, connectTimeoutMS: 30000}},
            replset: {socketOptions: {keepAlive: 300000, connectTimeoutMS: 30000}},
            auth: {role: 'admin'}
        },


        EMAIL_API: process.env.SENDGRID_API_KEY,
        EMAIL_CORPORATIVO_ADOPTA_UN_ANIMAL: process.env.EMAIL_CORPORATIVO_ADOPTA_UN_ANIMAL,

        //Configuracion de encriptacion de password
        ENCRYPTATION_KEY: process.env.ENCRYPTATION_KEY,
        SIGNING_KEY: process.env.SIGNING_KEY,

        //***************************************************
        //               CONFIGURAR AWS S3
        //***************************************************
        CONFIG_AWS_S3: {
            apiVersion: '2006-03-01',
            AWSService: 's3',
            region: process.env.regionS3,
            host: 'amazonaws.com',
            bucketProtectoras: process.env.bucketProtectoras,
            bucketAnimales: process.env.bucketAnimales
        },

        CREAR_CLIENTE_AWS_S3: (bucketName) => {

            AWS.config.update({
                region: process.env.regionS3,
                /*credentials: new AWS.CognitoIdentityCredentials({
                    IdentityPoolId: IdentityPoolId
                })*/
            });

            // Create an S3 client
            return new AWS.S3({
                apiVersion: '2006-03-01',
                params: {
                    Bucket: bucketName
                }
            });

        },

        kinesis: {
            region: process.env.regionS3,
            // stream : 'kclnodejssample',
            mapsStreams:{
                query: process.env.stremQquery,
                animal: process.env.streamAnimal,
                suscripcion: process.env.streamSuscripcion
            },
            shards: 1,
            waitBetweenDescribeCallsInSeconds: 5
        },

        CREAR_CLIENTE_AWS_KINESIS: () => {
            new AWS.Kinesis({region: process.env.regionS3});
        },


        tipos_de_email: {
            nuevo_animal_suscripcion_filtro: "nuevo_animal_suscripcion_filtro"

        }


    };


}


module.exports.parametros = {



    estados_animal: ['En adopción', 'Urgente', 'Adoptado', 'Acogido', 'Sacrificado', 'En cuarentena'],
    sexos: ['M', 'H'],
    tamanos_animal: ['MP', 'P', 'M', 'G', 'MG'],
    edades_animal: ['C', 'J', 'A', 'M', 'AB'],
    especie_animal: ['Gato', 'Perro'],

    asuntos_email: {
        nuevo_animal_suscripcion_filtro: "Nuevo animal en la plataforma! ^^",

    },


    tipos_de_email: {
        nuevo_animal_suscripcion_filtro: "nuevo_animal_suscripcion_filtro"

    }


};

